package aa4_woodshops;
/**
 * Enumeración que define los tipos de tablero disponibles en la gestión de inventario de productos de madera.
 * Cada constante representa un tipo diferente de tablero utilizado en la fabricación y venta de productos.
 */
public enum TipoTablero {
    AGLOMERADO, 
    CONTRACHAPADO,
    MDF 
    }