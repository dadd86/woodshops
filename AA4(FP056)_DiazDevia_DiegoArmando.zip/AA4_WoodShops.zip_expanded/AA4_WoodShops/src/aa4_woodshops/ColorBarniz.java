package aa4_woodshops;
/**
 * Enumeración que define los colores disponibles para los barnices en la gestión de productos de madera.
 * Estos colores son aplicables a barnices usados para tratar o decorar superficies de madera.
 */
public enum ColorBarniz {
    INCOLORO, 
    CAOBA, 
    NOGAL 
}