package aa4_woodshops;


import java.util.ArrayList;
import java.util.List;


/**
 * Clase que representa una tienda en el sistema de gestión de inventario.
 * Es inmutable en cuanto a sus propiedades de identificación, pero maneja listas mutables de ventas y productos.
 */
public class Tienda {
    private final String nombre;
    private final String direccion;
    private Almacen almacen;
    private List<Venta> ventas;

    /**
     * Constructor para crear una nueva tienda.
     *
     * @param nombre El nombre de la tienda, no puede ser nulo ni vacío.
     * @param direccion La dirección de la tienda, no puede ser nula ni vacía.
     * @throws IllegalArgumentException si el nombre o la dirección son nulos o están vacíos.
     */
    public Tienda(String nombre, String direccion) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre de la tienda no puede ser nulo ni vacío.");
        }
        if (direccion == null || direccion.trim().isEmpty()) {
            throw new IllegalArgumentException("La dirección de la tienda no puede ser nula ni vacía.");
        }
        this.nombre = nombre;
        this.direccion = direccion;
        this.almacen = new Almacen();
        this.ventas = new ArrayList<>();
    }

    /**
     * Añade un producto al almacén de la tienda.
     *
     * @param producto El producto a añadir, no puede ser nulo.
     */
    public void añadirProducto(Producto producto) {
        if (producto == null) {
            throw new IllegalArgumentException("Producto no puede ser nulo.");
        }
        almacen.añadirProducto(producto);
    }

    /**
     * Elimina un producto del almacén de la tienda basado en su código.
     *
     * @param codigoProducto Código del producto a eliminar.
     */
    public void removeProducto(String codigoProducto) {
        if (!almacen.eliminarProducto(codigoProducto)) {
            System.out.println("Producto con código " + codigoProducto + " no encontrado.");
        }
    }

    /**
     * Registra una venta en la tienda.
     *
     * @param venta La venta a registrar, no puede ser nula.
     */
    public synchronized void realizarVenta(Venta venta) {
        if (venta == null) {
            throw new IllegalArgumentException("La venta no puede ser nula.");
        }
        ventas.add(venta);
    }

    /**
     * Muestra todas las ventas realizadas en la tienda.
     */
    public void mostrarVentas() {
        for (Venta venta : ventas) {
            System.out.println(venta.toString());
        }
    }

    public String getNombre() {
        return nombre;
    }

    public String getDireccion() {
        return direccion;
    }

    public Almacen getAlmacen() {
        return almacen;
    }

    public List<Venta> getVentas() {
        return new ArrayList<>(ventas);  // Defensiva copia para preservar la encapsulación
    }

    /**
     * Lista todos los productos disponibles en el almacén de la tienda.
     */
    public void listarProductos() {
        almacen.listarProductos();
    }

    /**
     * Muestra el stock de un producto específico basado en su código.
     *
     * @param codigo Código del producto para consultar el stock.
     */
    public void mostrarStockProducto(String codigo) {
        almacen.mostrarStockProducto(codigo);
    }
}
