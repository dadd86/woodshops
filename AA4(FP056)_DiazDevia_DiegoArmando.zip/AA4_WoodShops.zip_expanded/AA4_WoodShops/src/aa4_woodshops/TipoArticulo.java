package aa4_woodshops;
/**
 * Enumeración que define los tipos de artículos disponibles en el inventario de la tienda.
 * Incluye diversos tipos de muebles y estructuras que pueden ser comprados por los clientes.
 */
public enum TipoArticulo {
    ESTANTERIA, 
    MESA, 
    SILLA, 
    ARMARIO 
}